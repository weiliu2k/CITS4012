Introduction to CITS4012's Jupyter Book
=======================================


[The best 8 Python NLP libraries](https://sunscrapers.com/blog/8-best-python-natural-language-processing-nlp-libraries/)

```{figure} ./images/nlp-libraries-comparison.jpg
:alt: NLP Library Comparison
:class: bg-primary mb-1
:width: 400px
```