Introduction to Neural Networks
===============================

```{figure} ../images/artificial_neuron.gif
:alt: Atifical Neuron Animation
:class: bg-primary mb-1
:width: 400px
```
