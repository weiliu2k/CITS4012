Basics of Python and Numpy
============================

Agenda

1. Installation

2. Basics

3. Iterables 

4. Numpy (for math and matrix operations)

5. Matplotlib (for plotting)

Original Notebook from Stanford 224n [http://web.stanford.edu/class/cs224n/readings/cs224n-python-review-code-updated.zip]
