Installing Pytorch
=======================

```
conda install pytorch torchvision -c pytorch
```